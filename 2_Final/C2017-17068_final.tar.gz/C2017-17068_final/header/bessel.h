#ifndef BESSEL_H
#define BESSEL_H

extern double bessel_I(int, double);
extern double bessel_I0(double);

#endif
